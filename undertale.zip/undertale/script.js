const icon = document.getElementById('icon');
const colors = ['red', 'mint', 'orange', 'blue', 'pink', 'green', 'yellow']; // 색상 배열
let colorIndex = 0;
let isHeart = false; // 첫 클릭 전에는 타이틀이 보임

// 타이틀에서 하트 이미지로 변경하는 함수
function changeToHeart() {
    icon.innerHTML = `
        <img src="main_source_png/heart_${colors[colorIndex]}.png" alt="heart" class="heart-icon" />
    `;
    const heartImage = icon.querySelector('img');
    heartImage.style.width = '15%'; // 이미지 크기 조정
    heartImage.style.height = 'auto'; // 비율 유지

    // 기본적으로 하트 이미지의 위치를 설정
    heartImage.style.position = 'relative'; // relative로 설정하여 위치 조정
    heartImage.style.top = '-5px'; // 기본 위치는 타이틀 바로 아래로 설정

    // 데스크톱 화면에서는 하트가 타이틀보다 훨씬 더 위로 올라가도록 top 값을 더 줄임
    if (window.innerWidth >= 1024) {
        heartImage.style.top = '-40px'; // 데스크톱 환경에서 하트를 훨씬 더 위로 올리기
    }
}

// 클릭 이벤트 리스너
icon.addEventListener('click', () => {
    if (!isHeart) {
        // 첫 클릭 후 타이틀을 하트로 변경
        changeToHeart();
        isHeart = true; // 이후에는 하트만 보이게 설정
    } else {
        // 하트 이미지의 색상만 변경
        const heartImage = icon.querySelector('img');
        if (heartImage) {
            heartImage.setAttribute('src', `main_source_png/heart_${colors[colorIndex]}.png`);
        }
    }

    // 색상 변경
    colorIndex = (colorIndex + 1) % colors.length;

    // 클릭 시 0.1초 동안 호버 효과를 비활성화
    const heartImage = icon.querySelector('img');
    if (heartImage) {
        heartImage.style.pointerEvents = 'none'; // 호버 효과 비활성화

        // 0.1초 후에 다시 호버 효과 활성화
        setTimeout(() => {
            heartImage.style.pointerEvents = 'auto'; // 호버 효과 다시 활성화
        }, 100); // 100ms 후
    }
});

// 윈도우 크기 변경 시에도 데스크톱 환경에서의 위치 조정이 반영되도록 이벤트 리스너 추가
window.addEventListener('resize', () => {
    if (isHeart) {
        const heartImage = icon.querySelector('img');
        if (heartImage) {
            // 화면 크기에 맞게 top 값을 조정
            if (window.innerWidth >= 1024) {
                heartImage.style.top = '-40px'; // 데스크톱 환경에서는 하트를 훨씬 더 위로 올리기
            } else {
                heartImage.style.top = '-5px'; // 모바일 등에서는 기본 위치로 설정
            }
        }
    }
});
// 메뉴 열기/닫기
const menuBtn = document.getElementById('menu-btn');
const sideMenu = document.getElementById('side-menu');

menuBtn.addEventListener('click', () => {
    sideMenu.classList.toggle('open');
});

// 메뉴 아이템 클릭 시 해당 링크로 이동
const menuItems = document.querySelectorAll('.menu-item');
menuItems.forEach(item => {
    item.addEventListener('click', () => {
        const link = item.getAttribute('data-link');
        window.location.href = link; // 해당 .html 페이지로 이동
    });
});