

// 이미지 요소들
const imgFlowey = document.getElementById('flowey-image');  // Toriel 이미지
const imgDialog = document.getElementById('dialog-image');  // 대사 이미지
const imgFace = document.getElementById('face-image');  // 얼굴 이미지

// 버튼들
const actButton = document.getElementById('act-button');

// move 이미지 요소들
const moveImagesContainer = document.getElementById('move-images-container');
const move01 = document.getElementById('move01');
const move02 = document.getElementById('move02');

// egg 변수, 처음에는 0
let mercy = 0, act = 0, fight = 0; // 각 변수를 초기화


actButton.addEventListener('click', () => {
    act++; // 버튼 클릭 시마다 act 값 증가

    let actIndex = act > 29 ? 29 : act; // act가 13을 넘으면 13으로 고정

    if (act > 28) {
        imgDialog.src = `source_svg/dialog_act/dialog${String(actIndex).padStart(2, '0')}.svg`;
        imgFlowey.src = "source_img/img_default04.png";
        imgFace.src = "source_img/face_default04.png";
        move01.src = `source_svg/move_act01/move${String(actIndex).padStart(2, '0')}.svg`;
        move02.src = `source_svg/move_act02/move${String(actIndex).padStart(2, '0')}.svg`;
    
        // move 이미지 보이기
        moveImagesContainer.style.visibility = "visible"; // 이미지 컨테이너 보이기
    
        
        function goToPage() {
            // 2초(2000밀리초) 후에 페이지 이동
            setTimeout(function() {
                window.location.href = "../asriel/ending.html";
            }, 2000); // 2000ms = 2초
        }
    
        // 페이지 이동 함수 호출
        goToPage();

    } 

    else if (act <= 28 && act >=18) {
        imgDialog.src = `source_svg/dialog_act/dialog${String(actIndex).padStart(2, '0')}.svg`;
        imgFlowey.src = "source_img/img_default03.png";
        imgFace.src = "source_img/face_default03.png";
        move01.src = `source_svg/move_act01/move${String(actIndex).padStart(2, '0')}.svg`;
        move02.src = `source_svg/move_act02/move${String(actIndex).padStart(2, '0')}.svg`;
    
        // move 이미지 보이기
        moveImagesContainer.style.visibility = "visible"; // 이미지 컨테이너 보이기
    }
    
    else{
    // 기본 ACT 이미지 설정
    imgDialog.src = `source_svg/dialog_act/dialog${String(actIndex).padStart(2, '0')}.svg`;
    imgFlowey.src = "source_img/img_default01.png";
    imgFace.src = "source_img/face_default01.png";
    move01.src = `source_svg/move_act01/move${String(actIndex).padStart(2, '0')}.svg`;
    move02.src = `source_svg/move_act02/move${String(actIndex).padStart(2, '0')}.svg`;

    // move 이미지 보이기
    moveImagesContainer.style.visibility = "visible"; // 이미지 컨테이너 보이기

        }

});





   // Scroll-down 아이콘의 마우스 오버 이벤트
   const scrollDownIcon = document.getElementById('scroll-down-icon');
   scrollDownIcon.addEventListener('mouseover', () => {
     scrollDownIcon.style.opacity = '0';  // 페이드 아웃
     scrollDownIcon.style.visibility = 'hidden';  // 클릭 방지
   });

       // 메뉴 열기/닫기
       const menuBtn = document.getElementById('menu-btn');
       const sideMenu = document.getElementById('side-menu');

       menuBtn.addEventListener('click', () => {
           sideMenu.classList.toggle('open');
       });

       // 메뉴 아이템 클릭 시 해당 링크로 이동
       const menuItems = document.querySelectorAll('.menu-item');
       menuItems.forEach(item => {
           item.addEventListener('click', () => {
               const link = item.getAttribute('data-link');
               window.location.href = link; // 해당 .html 페이지로 이동
           });
       });