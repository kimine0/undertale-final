

// 이미지 요소들
const imgFlowey = document.getElementById('flowey-image');  // Toriel 이미지
const imgDialog = document.getElementById('dialog-image');  // 대사 이미지

// 버튼들
const actButton = document.getElementById('act-button');
const fightButton = document.getElementById('fight-button');
const mercyButton = document.getElementById('mercy-button');



// egg 변수, 처음에는 0
let mercy = 0, act = 0, fight = 0; // 각 변수를 초기화






fightButton.addEventListener('click', () => {
    // 기본 FIGHT 이미지로 설정
    imgDialog.src = `source_svg/dialog01.svg`;
    imgFlowey.src = "source_img/img_default02.png";


    function goToPage() {
        // 2초(2000밀리초) 후에 페이지 이동
        setTimeout(function() {
            window.location.href = "../flowey_main/flowey.html";
        }, 2000); // 2000ms = 2초
    }


    // 페이지 이동 함수 호출
    goToPage();
});


mercyButton.addEventListener('click', () => {



    // 기본 ACT 이미지 설정
    imgDialog.src = `source_svg/dialog02.svg`;
    imgFlowey.src = "source_img/img_default02.png";



    function goToPage() {
        // 2초(2000밀리초) 후에 페이지 이동
        setTimeout(function() {
            window.location.href = "../asriel/asriel.html";
        }, 2000); // 2000ms = 2초
    }

    // 페이지 이동 함수 호출
    goToPage();

});



   // Scroll-down 아이콘의 마우스 오버 이벤트
   const scrollDownIcon = document.getElementById('scroll-down-icon');
   scrollDownIcon.addEventListener('mouseover', () => {
     scrollDownIcon.style.opacity = '0';  // 페이드 아웃
     scrollDownIcon.style.visibility = 'hidden';  // 클릭 방지
   });

       // 메뉴 열기/닫기
       const menuBtn = document.getElementById('menu-btn');
       const sideMenu = document.getElementById('side-menu');

       menuBtn.addEventListener('click', () => {
           sideMenu.classList.toggle('open');
       });

       // 메뉴 아이템 클릭 시 해당 링크로 이동
       const menuItems = document.querySelectorAll('.menu-item');
       menuItems.forEach(item => {
           item.addEventListener('click', () => {
               const link = item.getAttribute('data-link');
               window.location.href = link; // 해당 .html 페이지로 이동
           });
       });